---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
~ [[Jardineiro]]  

> [!trees] [[Plante]] | **[[Cultive]]** | [[Questione]] | [[Replantar]] | [[Revitalizar]] | [[Revisitar]] — [[Arquiteto]] ⤴️  

Se você marcou notas com `#garden/cultivate`, então você quer **desenvolver essas notas ainda mais.**  
Isso pode significar adicionar mais reflexões, contexto, links, fontes ou de alguma forma trazer mais valor a elas.  
Você também pode fazer novas observações — esclarecendo, criticando ou expandindo as ideias dentro delas.  

