---
up: "[[++ Gestão de Conhecimento]]"
collection: "[[Gestão de Conhecimento]]"
cssclasses:
  - hide-properties_editing
  - hide-properties_reading
---
A pasta **+** é sua **caixa de entrada** e **central de guias rápidos** — o ponto de partida para tudo que é novo ou precisa estar sempre acessível.