--- start-multi-column: <% tp.system.prompt("region")%>

<% tp.system.clipboard() %>

\--- end-column ---

<%tp.file.cursor()%>

--- end-multi-column