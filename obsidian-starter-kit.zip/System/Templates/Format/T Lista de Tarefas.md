---
created: ["{{date}} {{time}}"]
tags:
- Lista/
---
# 💠 Lista de Tarefas

## 🔴 URGENTE  
*Faça agora*  
- [ ] Tarefa 1  
- [ ] Tarefa 2  
- [ ] Tarefa 3  

### 🟠 IMPORTANTE  
*Faça após as tarefas acima*  
- [ ] Tarefa 1  
- [ ] Tarefa 2  
- [ ] Tarefa 3  

#### 🟡 NÃO URGENTE / IMPORTANTE  
*Decida quando fazer*  
- [ ] Tarefa 1  
- [ ] Tarefa 2  
- [ ] Tarefa 3  

##### 🟢 Concluídas  
- [x] Tarefa 1  
- [x] Tarefa 2  
- [x] Tarefa 3  
